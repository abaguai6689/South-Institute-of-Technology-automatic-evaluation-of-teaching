(function() {
    // 1. 评教列表页面：注入“一键进入评教”按钮
    if (window.location.href.includes("whatIEvaluatedDetails")) {
        let btn = document.createElement("button");
        btn.innerText = "一键进入评教";
        btn.style.cssText = "position: fixed; top: 20px; right: 20px; z-index: 9999; padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; box-shadow: 0 2px 5px rgba(0,0,0,0.3);";
        document.body.appendChild(btn);

        btn.onclick = () => {
            let rows = document.querySelectorAll('.el-table__row');
            let clicked = false;
            for (let row of rows) {
                let status = row.querySelector('.d_submit_tag');
                // 寻找状态为“未评”的行
                if (status && status.innerText.includes('未评')) {
                    let evalBtn = Array.from(row.querySelectorAll('.d_button_text')).find(a => a.innerText.includes('评价'));
                    if (evalBtn) {
                        evalBtn.click();
                        clicked = true;
                        break;
                    }
                }
            }
            if (!clicked) {
                alert("所有课程均已评教完成！");
            }
        };
    }

    // 2. 评教表单页面：注入“自动填写并提交”按钮
    if (window.location.href.includes("questionnaireInfo")) {
        let btn = document.createElement("button");
        btn.innerText = "自动填写并提交";
        btn.style.cssText = "position: fixed; top: 20px; right: 20px; z-index: 9999; padding: 10px 20px; background: #2196F3; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; box-shadow: 0 2px 5px rgba(0,0,0,0.3);";
        document.body.appendChild(btn);

        btn.onclick = () => {
            // 根据已完成模版提取的12道题具体分数，总计刚好为 93.0 分
            const templateScores = [10.0, 9.0, 9.0, 5.0, 5.0, 5.0, 5.0, 5.0, 10.0, 10.0, 10.0, 10.0];
            
            // 自动填写打分题
            let scoreInputs = document.querySelectorAll('input.dafen');
            scoreInputs.forEach((input, index) => {
                if (index < templateScores.length) {
                    input.value = templateScores[index];
                } else {
                    // 若系统增加了额外的题目，安全起见默认填入该题允许的最高分
                    input.value = input.getAttribute('maxscore') || "5.0";
                }
                // 触发底层框架的事件监听，确保数据被前端框架双向绑定成功
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
                input.dispatchEvent(new Event('blur', { bubbles: true }));
            });

            // 自动填写简答题
            let textareas = document.querySelectorAll('textarea.blueTextarea');
            textareas.forEach(ta => {
                ta.value = "无";
                ta.dispatchEvent(new Event('input', { bubbles: true }));
                ta.dispatchEvent(new Event('change', { bubbles: true }));
                ta.dispatchEvent(new Event('blur', { bubbles: true }));
            });

            // 模拟人工操作，延迟 800ms 后自动触发底部提交按钮
            setTimeout(() => {
                let submitBtn = document.querySelector('a.save');
                if (submitBtn) {
                    submitBtn.click();
                }
            }, 800);
        };
    }
})();
